"""
Integrated Thermal Image Analyzer
Uses specialized solar panel fault detection models from Web-API
Supports AWS S3 and EFS for model storage
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import io
import json
import numpy as np
import os
import gc
from os import fspath
from pathlib import Path
from dotenv import load_dotenv
from tensorflow.keras.models import load_model

# Try to import psutil for memory monitoring (optional)
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

# Import Web-API utilities
from utils.utils import get_yolo_boxes, disconnected
from utils.colors import get_color
import cv2

# Load environment variables
load_dotenv()

# Try to import boto3 for AWS support (optional)
try:
    import boto3
    AWS_AVAILABLE = True
except ImportError:
    AWS_AVAILABLE = False
    print("Warning: boto3 not installed. AWS S3/EFS support disabled.")

# Configuration
base_path = Path(".")
storage_path = base_path.joinpath("storage")

app = Flask(__name__)
# Configure CORS to allow all origins and methods
CORS(app, 
     origins="*", 
     methods=["GET", "POST", "OPTIONS"],
     allow_headers=["Content-Type", "Authorization"],
     supports_credentials=False)

# Model configuration - same as Web-API
class ModelManager:
    """Manages loading and access to the three YOLOv3 models
    Supports local storage, AWS EFS, and AWS S3"""
    
    net_h, net_w = 416, 416
    obj_thresh, nms_thresh = 0.5, 0.45
    
    # AWS configuration
    efs_path = Path(os.getenv('EFS_MODEL_PATH', '/mnt/efs/models'))
    s3_bucket = os.getenv('MODEL_S3_BUCKET', None)
    if s3_bucket:
        s3_bucket = s3_bucket.strip()  # Remove leading/trailing whitespace
    aws_region = os.getenv('AWS_REGION', 'us-east-2').strip()
    
    # Check if EFS is available
    use_efs = efs_path.exists() and any(efs_path.glob('*.h5'))
    
    # Local storage paths (fallback)
    local_storage_path = storage_path.joinpath("model")
    
    model_compiled = {
        "model_1": "yolo3_full_fault_1.h5",
        "model_2": "yolo3_full_fault_4.h5",
        "model_3": "yolo3_full_panel.h5",
    }
    
    model_config = {
        "model_1": fspath(
            storage_path.joinpath("model/config/config_full_yolo_fault_1_infer.json")
        ),
        "model_2": fspath(
            storage_path.joinpath("model/config/config_full_yolo_fault_4_infer.json")
        ),
        "model_3": fspath(
            storage_path.joinpath("model/config/config_full_yolo_panel.json")
        ),
    }
    
    _models = None
    _models_loaded = False
    _configs_loaded = None
    _model_paths = None
    
    @classmethod
    def _get_model_paths(cls):
        """Get model paths from EFS, S3, or local storage"""
        if cls._model_paths is not None:
            return cls._model_paths
        
        # Priority 1: EFS (if available and has models)
        if cls.use_efs:
            print(f"Using models from EFS: {cls.efs_path}")
            cls._model_paths = {
                "model_1": fspath(cls.efs_path / cls.model_compiled["model_1"]),
                "model_2": fspath(cls.efs_path / cls.model_compiled["model_2"]),
                "model_3": fspath(cls.efs_path / cls.model_compiled["model_3"]),
            }
            return cls._model_paths
        
        # Priority 2: S3 (if configured and AWS available)
        if cls.s3_bucket and AWS_AVAILABLE:
            print(f"Downloading models from S3 bucket: {cls.s3_bucket}")
            cls._model_paths = cls._download_from_s3()
            return cls._model_paths
        
        # Priority 3: Local storage (fallback)
        print(f"Using models from local storage: {cls.local_storage_path}")
        cls._model_paths = {
            "model_1": fspath(cls.local_storage_path / cls.model_compiled["model_1"]),
            "model_2": fspath(cls.local_storage_path / cls.model_compiled["model_2"]),
            "model_3": fspath(cls.local_storage_path / cls.model_compiled["model_3"]),
        }
        return cls._model_paths
    
    @classmethod
    def _download_from_s3(cls, model_key=None):
        """Download models from S3 to local cache
        
        Args:
            model_key: If provided, only download this specific model. Otherwise download all.
        """
        if not AWS_AVAILABLE:
            raise ImportError("boto3 is required for S3 support. Install with: pip install boto3")
        
        s3 = boto3.client('s3', region_name=cls.aws_region)
        cache_dir = Path('/tmp/models')
        cache_dir.mkdir(parents=True, exist_ok=True)
        
        # If model_key is specified, only process that model
        models_to_process = {model_key: cls.model_compiled[model_key]} if model_key else cls.model_compiled
        
        model_paths = {}
        for key, filename in models_to_process.items():
            local_path = cache_dir / filename
            s3_key = f"models/{filename}"
            
            if not local_path.exists():
                print(f"Downloading {filename} from S3...")
                try:
                    s3.download_file(cls.s3_bucket, s3_key, str(local_path))
                    print(f"✓ Downloaded {filename}")
                except Exception as e:
                    print(f"✗ Failed to download {filename} from S3: {e}")
                    # Fallback to local if S3 download fails
                    local_fallback = cls.local_storage_path / filename
                    if local_fallback.exists():
                        print(f"  Falling back to local: {local_fallback}")
                        model_paths[key] = fspath(local_fallback)
                        continue
                    raise
            else:
                print(f"✓ Using cached {filename}")
            
            model_paths[key] = fspath(local_path)
        
        return model_paths
    
    @classmethod
    def _get_single_model_path(cls, model_key):
        """Get path for a single model without downloading all models"""
        # Priority 1: EFS (if available and has models)
        if cls.use_efs:
            filename = cls.model_compiled[model_key]
            model_path = cls.efs_path / filename
            if model_path.exists():
                return fspath(model_path)
        
        # Priority 2: S3 (if configured and AWS available) - download only this model
        if cls.s3_bucket and AWS_AVAILABLE:
            print(f"Downloading {model_key} from S3 bucket: {cls.s3_bucket}")
            model_paths = cls._download_from_s3(model_key=model_key)
            return model_paths.get(model_key)
        
        # Priority 3: Local storage (fallback)
        filename = cls.model_compiled[model_key]
        local_path = cls.local_storage_path / filename
        return fspath(local_path)
    
    @classmethod
    def _load_models(cls):
        """Load models once (lazy initialization)
        
        WARNING: Loading three YOLOv3 models requires ~1-2GB RAM.
        Render free tier (512MB) will fail. Use AWS ECS/Fargate (2GB+) or SageMaker.
        """
        if not cls._models_loaded:
            print("Loading solar panel fault detection models...")
            
            # Check available memory before loading (if psutil available)
            if PSUTIL_AVAILABLE:
                try:
                    process = psutil.Process()
                    mem_info = process.memory_info()
                    available_mem_mb = psutil.virtual_memory().available / (1024 * 1024)
                    
                    print(f"Available memory: {available_mem_mb:.1f} MB")
                    print(f"Current process memory: {mem_info.rss / (1024 * 1024):.1f} MB")
                    
                    # Warn if memory is low (less than 1GB available)
                    if available_mem_mb < 1024:
                        print(f"⚠ WARNING: Low memory ({available_mem_mb:.1f} MB). Model loading may fail.")
                        print("⚠ Three YOLOv3 models require ~1-2GB RAM.")
                        print("⚠ Solutions:")
                        print("  1. Deploy to AWS ECS/Fargate with 2GB+ memory")
                        print("  2. Use AWS SageMaker for model inference")
                        print("  3. Upgrade Render plan to paid tier (2GB+)")
                except Exception:
                    pass  # Continue if memory check fails
            
            try:
                model_paths = cls._get_model_paths()
                
                # Verify all model files exist
                for key, path in model_paths.items():
                    if not Path(path).exists():
                        raise FileNotFoundError(f"Model file not found: {path}")
                
                # Load models one at a time to monitor memory
                cls._models = {}
                for key, path in model_paths.items():
                    print(f"Loading {key} from {path}...")
                    try:
                        cls._models[key] = load_model(path)
                        gc.collect()  # Force garbage collection after each model
                        
                        # Check memory after loading (if psutil available)
                        if PSUTIL_AVAILABLE:
                            try:
                                mem_after = process.memory_info()
                                mem_used_mb = (mem_after.rss - mem_info.rss) / (1024 * 1024)
                                print(f"  Memory used so far: {mem_used_mb:.1f} MB")
                            except:
                                pass
                    except MemoryError:
                        print(f"✗ Out of memory while loading {key}")
                        print("This deployment platform doesn't have enough memory for model inference.")
                        print("Please deploy to AWS ECS/Fargate (2GB+) or use AWS SageMaker.")
                        raise
                
                cls._models_loaded = True
                if PSUTIL_AVAILABLE:
                    try:
                        final_mem = process.memory_info()
                        total_mem_mb = (final_mem.rss - mem_info.rss) / (1024 * 1024)
                        print(f"✓ All models loaded successfully (total: {total_mem_mb:.1f} MB)")
                    except:
                        print("✓ All models loaded successfully")
                else:
                    print("✓ All models loaded successfully")
            except MemoryError as e:
                print(f"✗ Out of memory while loading models: {e}")
                print("\n" + "="*60)
                print("MEMORY LIMIT EXCEEDED")
                print("="*60)
                print("Three YOLOv3 models require ~1-2GB RAM.")
                print("Render free tier (512MB) is insufficient.")
                print("\nRecommended Solutions:")
                print("1. Deploy to AWS ECS/Fargate with 2GB+ memory")
                print("2. Use AWS SageMaker for model inference (models stay on AWS)")
                print("3. Upgrade Render plan to paid tier")
                print("="*60)
                raise
            except Exception as e:
                print(f"✗ Error loading models: {e}")
                print("Make sure model files are available in:")
                print(f"  - EFS: {cls.efs_path}")
                if cls.s3_bucket:
                    print(f"  - S3: s3://{cls.s3_bucket}/models/")
                print(f"  - Local: {cls.local_storage_path}")
                raise
        return cls._models
    
    @classmethod
    def _load_configs(cls):
        """Load model configurations"""
        if cls._configs_loaded is None:
            cls._configs_loaded = {}
            for key, config_path in cls.model_config.items():
                try:
                    with open(config_path) as f:
                        cls._configs_loaded[key] = json.load(f)
                except FileNotFoundError:
                    print(f"Warning: Config file not found: {config_path}")
                    cls._configs_loaded[key] = None
        return cls._configs_loaded
    
    @property
    def models(self):
        """Access to models (lazy loading)"""
        return self._load_models()
    
    @property
    def configs(self):
        """Access to configs (lazy loading)"""
        return self._load_configs()


model_manager = ModelManager()


def pil_to_numpy(image):
    """Convert PIL Image to numpy array (RGB format)"""
    return np.array(image)


def numpy_to_pil(image_array):
    """Convert numpy array to PIL Image"""
    return Image.fromarray(image_array.astype('uint8'))


def transform_detections_to_frontend_format(objects):
    """
    Transform Web-API detection format to frontend format
    
    Web-API format: {xmin, xmax, ymin, ymax, label, score, class}
    Frontend format: {label, confidence, coordinates: [x, y, width, height], severity}
    """
    detections = []
    
    for obj in objects:
        xmin = obj.get("xmin", 0)
        ymin = obj.get("ymin", 0)
        xmax = obj.get("xmax", 0)
        ymax = obj.get("ymax", 0)
        
        # Convert to [x, y, width, height] format
        x = float(xmin)
        y = float(ymin)
        width = float(xmax - xmin)
        height = float(ymax - ymin)
        
        # Get confidence score
        score_str = obj.get("score", "0")
        try:
            confidence = float(score_str)
        except (ValueError, TypeError):
            confidence = 0.0
        
        # Determine severity based on confidence
        if confidence > 0.8:
            severity = "High"
        elif confidence > 0.5:
            severity = "Medium"
        else:
            severity = "Low"
        
        detections.append({
            "label": obj.get("label", "Unknown"),
            "confidence": round(confidence, 2),
            "coordinates": [x, y, width, height],
            "severity": severity,
            "class": obj.get("class", ""),
        })
    
    return detections


@app.route("/", methods=["GET", "OPTIONS"])
def home():
    """Health check endpoint"""
    if request.method == "OPTIONS":
        return "", 200
    """Health check endpoint"""
    models_status = {}
    if model_manager._models_loaded and model_manager._models:
        for key in ["model_1", "model_2", "model_3"]:
            models_status[key] = key in model_manager._models
    else:
        models_status = {
            "model_1": False,
            "model_2": False,
            "model_3": False
        }
    
    return jsonify({
        "status": "Online",
        "message": "Solar Panel Fault Detection API is ready!",
        "models_loaded": model_manager._models_loaded,
        "models_status": models_status
    })


@app.route("/models/load/<model_name>", methods=["POST", "OPTIONS"])
def load_model_endpoint(model_name):
    """Load a specific model by name (model_1, model_2, or model_3)"""
    if request.method == "OPTIONS":
        return "", 200
    
    if model_name not in ["model_1", "model_2", "model_3"]:
        return jsonify({
            "error": "Invalid model name",
            "message": "Model name must be one of: model_1, model_2, model_3"
        }), 400
    
    try:
        # Check if model is already loaded
        if model_manager._models_loaded and model_manager._models:
            if model_name in model_manager._models:
                return jsonify({
                    "status": "already_loaded",
                    "message": f"{model_name} is already loaded",
                    "model": model_name
                })
        
        # Load the specific model
        print(f"Loading {model_name} on demand...")
        # Get path for only this specific model (don't download all models)
        model_path_str = model_manager._get_single_model_path(model_name)
        
        if not model_path_str:
            return jsonify({
                "error": "Model path not found",
                "message": f"Could not find path for {model_name}"
            }), 404
        
        model_path = Path(model_path_str)
        if not model_path.exists():
            return jsonify({
                "error": "Model file not found",
                "message": f"Model file not found: {model_path}"
            }), 404
        
        # Initialize models dict if needed
        if model_manager._models is None:
            model_manager._models = {}
        
        # Load the specific model
        model_manager._models[model_name] = load_model(str(model_path))
        gc.collect()
        
        # Mark as loaded if all models are loaded, otherwise partial
        if len(model_manager._models) == 3:
            model_manager._models_loaded = True
        
        print(f"✓ {model_name} loaded successfully")
        
        return jsonify({
            "status": "loaded",
            "message": f"{model_name} loaded successfully",
            "model": model_name,
            "models_loaded": list(model_manager._models.keys())
        })
        
    except MemoryError as e:
        return jsonify({
            "error": "Out of memory",
            "message": f"Failed to load {model_name}: Out of memory. This platform may not have enough RAM.",
            "model": model_name
        }), 507  # 507 Insufficient Storage
        
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        print(f"Error loading {model_name}: {e}")
        print(error_trace)
        return jsonify({
            "error": str(e),
            "message": f"Failed to load {model_name}",
            "model": model_name
        }), 500


@app.route("/models/status", methods=["GET", "OPTIONS"])
def models_status():
    """Get status of all models"""
    if request.method == "OPTIONS":
        return "", 200
    """Get status of all models"""
    # Check actual model dictionary, not just the _models_loaded flag
    models_status_dict = {}
    if model_manager._models:
        for key in ["model_1", "model_2", "model_3"]:
            models_status_dict[key] = key in model_manager._models
    else:
        models_status_dict = {
            "model_1": False,
            "model_2": False,
            "model_3": False
        }
    
    model_names = {
        "model_1": "Soiling Fault Detection",
        "model_2": "Diode Fault Detection",
        "model_3": "Panel Disconnect Detection"
    }
    
    return jsonify({
        "models": {
            key: {
                "loaded": models_status_dict[key],
                "name": model_names[key]
            }
            for key in ["model_1", "model_2", "model_3"]
        },
        "all_loaded": all(models_status_dict.values())
    })


@app.route("/analyze", methods=["POST", "OPTIONS"])
def analyze_image():
    """
    Analyze uploaded thermal image for solar panel faults
    Accepts multipart/form-data with 'file' field
    Returns detections in frontend-compatible format
    """
    if request.method == "OPTIONS":
        return "", 200
    
    try:
        # Check if file was uploaded
        if 'file' not in request.files:
            return jsonify({"error": "No file provided"}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No file selected"}), 400
        
        # Read image data
        image_data = file.read()
        pil_image = Image.open(io.BytesIO(image_data))
        
        # Collect image metadata
        image_info = {
            "size": pil_image.size,
            "mode": pil_image.mode,
            "format": pil_image.format or "UNKNOWN",
            "width": pil_image.width,
            "height": pil_image.height
        }
        
        # Convert PIL to numpy array (RGB format)
        image_array = pil_to_numpy(pil_image)
        
        # Ensure image is in RGB format (3 channels)
        if len(image_array.shape) == 2:
            # Grayscale, convert to RGB
            image_array = cv2.cvtColor(image_array, cv2.COLOR_GRAY2RGB)
        elif image_array.shape[2] == 4:
            # RGBA, convert to RGB
            image_array = cv2.cvtColor(image_array, cv2.COLOR_RGBA2RGB)
        elif image_array.shape[2] != 3:
            return jsonify({"error": f"Unsupported image format: {image_array.shape}"}), 400
        
        # Prepare images list (Web-API expects list)
        images = [image_array]
        
        # Load model configurations
        configs = model_manager.configs
        if not all(configs.values()):
            return jsonify({
                "error": "Model configuration files not found",
                "message": "Please ensure config files are in storage/model/config/"
            }), 500
        
        # Extract labels from configs
        labels_1 = configs["model_1"]["model"]["labels"]
        labels_2 = configs["model_2"]["model"]["labels"]
        labels_3 = configs["model_3"]["model"]["labels"]
        
        # Get models (may be partially loaded)
        models = model_manager._models if model_manager._models else {}
        
        # Check which models are available
        missing_models = []
        if "model_1" not in models:
            missing_models.append("model_1 (Soiling Fault)")
        if "model_2" not in models:
            missing_models.append("model_2 (Diode Fault)")
        if "model_3" not in models:
            missing_models.append("model_3 (Panel Disconnect)")
        
        if missing_models:
            return jsonify({
                "error": "Models not loaded",
                "message": "Please load the required models first using the model loader",
                "missing_models": missing_models,
                "available_endpoint": "/models/load/<model_name>"
            }), 503  # Service Unavailable
        
        # Run inference with all three models
        boxes_p_1 = get_yolo_boxes(
            models["model_1"],
            images,
            model_manager.net_h,
            model_manager.net_w,
            configs["model_1"]["model"]["anchors"],
            model_manager.obj_thresh,
            model_manager.nms_thresh,
        )
        
        boxes_p_2 = get_yolo_boxes(
            models["model_2"],
            images,
            model_manager.net_h,
            model_manager.net_w,
            configs["model_2"]["model"]["anchors"],
            model_manager.obj_thresh,
            model_manager.nms_thresh,
        )
        
        boxes_p_3 = get_yolo_boxes(
            models["model_3"],
            images,
            model_manager.net_h,
            model_manager.net_w,
            configs["model_3"]["model"]["anchors"],
            model_manager.obj_thresh,
            model_manager.nms_thresh,
        )
        
        # Filter boxes by confidence threshold
        boxes_p_1 = [
            [box for box in boxes_image if box.get_score() > model_manager.obj_thresh]
            for boxes_image in boxes_p_1
        ]
        boxes_p_2 = [
            [box for box in boxes_image if box.get_score() > model_manager.obj_thresh]
            for boxes_image in boxes_p_2
        ]
        boxes_p_3 = [
            [box for box in boxes_image if box.get_score() > model_manager.obj_thresh]
            for boxes_image in boxes_p_3
        ]
        
        # Apply special processing for panel disconnect (model_3)
        boxes_p_3 = [
            disconnected(image, boxes_image)
            for image, boxes_image in zip(images, boxes_p_3)
        ]
        
        # Collect all detections
        all_objects = []
        
        # Process model_1 detections (Soiling Fault)
        for box in boxes_p_1[0]:
            all_objects.append({
                "class": labels_1[box.get_label()],
                "label": "Soiling Fault",
                "score": str(box.get_score()),
                "xmin": box.xmin,
                "xmax": box.xmax,
                "ymin": box.ymin,
                "ymax": box.ymax,
            })
        
        # Process model_2 detections (Diode Fault)
        for box in boxes_p_2[0]:
            all_objects.append({
                "class": labels_2[box.get_label()],
                "label": "Diode Fault",
                "score": str(box.get_score()),
                "xmin": box.xmin,
                "xmax": box.xmax,
                "ymin": box.ymin,
                "ymax": box.ymax,
            })
        
        # Process model_3 detections (Panel Disconnect)
        for box in boxes_p_3[0]:
            all_objects.append({
                "class": labels_3[box.get_label()],
                "label": "Panel Disconnect",
                "score": str(box.classes[0]),
                "xmin": box.xmin,
                "xmax": box.xmax,
                "ymin": box.ymin,
                "ymax": box.ymax,
            })
        
        # Transform to frontend format
        detections = transform_detections_to_frontend_format(all_objects)
        
        # Build response
        response = {
            "detections": detections,
            "analysis": detections,  # Keep for backward compatibility
            "image_info": image_info,
            "model_info": {
                "model": "YOLOv3 Solar Panel Fault Detection",
                "model_type": "Multi-model ensemble (Soiling, Diode, Panel Disconnect)",
                "note": "Specialized models for photovoltaic fault detection in thermal images."
            }
        }
        
        # Add warning if no detections found
        if len(detections) == 0:
            response["warning"] = (
                "No faults detected in the thermal image. This could mean the solar panels "
                "are in good condition, or the image may need adjustment."
            )
        
        return jsonify(response)
        
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        print(f"Error during analysis: {e}")
        print(error_trace)
        return jsonify({
            "error": str(e),
            "message": "An error occurred during image analysis"
        }), 500


# DO NOT pre-load models on startup on Render (memory constraints)
# Models will be loaded lazily on first request
# This prevents OOM errors on platforms with limited memory (e.g., Render free tier)
if os.getenv('PRELOAD_MODELS', 'false').lower() == 'true':
    try:
        model_manager._load_models()
        model_manager._load_configs()
        print("✓ Models pre-loaded on startup")
    except Exception as e:
        print(f"Warning: Could not pre-load models: {e}")
        print("Models will be loaded on first request")
else:
    print("Models will be loaded lazily on first request (PRELOAD_MODELS=false)")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
